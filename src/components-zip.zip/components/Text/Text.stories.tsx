import type { Meta, StoryObj } from "@storybook/react-webpack5";
import { Text } from "./Text";

const meta: Meta<typeof Text> = {
  title: "Components/Text",
  component: Text,
  argTypes: {
    text: { control: "text" },
    backgroundColor: { control: "color" },
    disabled: { control: "boolean" },
    size: { control: "radio", options: ["sm", "md", "lg"] },
  },
};

export default meta;
type Story = StoryObj<typeof Text>;

export const Default: Story = {
  args: {
    text: "This is some text.",
    backgroundColor: "transparent",
    disabled: false,
    size: "md",
  },
};

export const Disabled: Story = {
  args: {
    text: "This text is disabled.",
    backgroundColor: "transparent",
    disabled: true,
    size: "md",
  },
};