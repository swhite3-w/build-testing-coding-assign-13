import type { Meta, StoryObj } from "@storybook/react-webpack5";
import { Table } from "./Table";

// temporary HTML children so the Table story renders now.
// Later we’ll replace these with your TableHeader/TableRow/TableCell components.
const Demo = () => (
  <Table>
    <thead>
      <tr>
        <th style={{ textAlign: "left", padding: 8 }}>Name</th>
        <th style={{ textAlign: "left", padding: 8 }}>Value</th>
      </tr>
    </thead>
    <tbody>
      <tr>
        <td style={{ padding: 8 }}>Row 1</td>
        <td style={{ padding: 8 }}>123</td>
      </tr>
    </tbody>
  </Table>
);

const meta: Meta<typeof Table> = {
  title: "Components/Table",
  component: Table,
  argTypes: {
    backgroundColor: { control: "color" },
    disabled: { control: "boolean" },
  },
  render: (args) => (
    <Table disabled={args.disabled} backgroundColor={args.backgroundColor}>
      <thead>
        <tr>
          <th style={{ textAlign: "left", padding: 8 }}>Name</th>
          <th style={{ textAlign: "left", padding: 8 }}>Value</th>
        </tr>
      </thead>
      <tbody>
        <tr>
          <td style={{ padding: 8 }}>Row 1</td>
          <td style={{ padding: 8 }}>123</td>
        </tr>
      </tbody>
    </Table>
  ),
};

export default meta;
type Story = StoryObj<typeof Table>;

export const Default: Story = {
  args: {
    backgroundColor: "transparent",
    disabled: false,
  },
};

export const Disabled: Story = {
  args: {
    backgroundColor: "transparent",
    disabled: true,
  },
};