import type { Meta, StoryObj } from "@storybook/react-webpack5";
import { Table } from "../Table";
import { TableHeader } from "./TableHeader";
import type { ComponentProps } from "react";

const meta: Meta<typeof TableHeader> = {
  title: "Components/TableHeader",
  component: TableHeader,
  argTypes: {
    backgroundColor: { control: "color" },
    disabled: { control: "boolean" },
  },
  render: (args: ComponentProps<typeof TableHeader>) => (
    <Table>
      <TableHeader disabled={args.disabled} backgroundColor={args.backgroundColor}>
        <tr>
          <th style={{ textAlign: "left", padding: 8 }}>Name</th>
          <th style={{ textAlign: "left", padding: 8 }}>Value</th>
        </tr>
      </TableHeader>
      <tbody>
        <tr>
          <td style={{ padding: 8 }}>Row 1</td>
          <td style={{ padding: 8 }}>123</td>
        </tr>
      </tbody>
    </Table>
  ),
};

export default meta;
type Story = StoryObj<typeof TableHeader>;

export const Default: Story = {
  args: {
    backgroundColor: "#f5f5f5",
    disabled: false,
  },
};

export const Disabled: Story = {
  args: {
    backgroundColor: "#f5f5f5",
    disabled: true,
  },
};