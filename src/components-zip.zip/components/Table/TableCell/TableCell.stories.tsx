import type { Meta, StoryObj } from "@storybook/react-webpack5";
import { Table } from "../Table";
import { TableHeader } from "../TableHeader";
import { TableRow } from "../TableRow";
import { TableCell } from "./TableCell";
import type { ComponentProps } from "react";

const meta: Meta<typeof TableCell> = {
  title: "Components/TableCell",
  component: TableCell,
  argTypes: {
    backgroundColor: { control: "color" },
    disabled: { control: "boolean" },
  },
};

export default meta;
type Story = StoryObj<typeof TableCell>;

export const Default: Story = {
  args: { disabled: false, backgroundColor: "transparent" },
  render: (args: ComponentProps<typeof TableCell>) => (
    <Table>
      <TableHeader>
        <tr>
          <th style={{ padding: 8 }}>Name</th>
        </tr>
      </TableHeader>
      <tbody>
        <TableRow>
          <TableCell {...args}>Cell Content</TableCell>
        </TableRow>
      </tbody>
    </Table>
  ),
};

export const Disabled: Story = {
  args: { disabled: true, backgroundColor: "transparent" },
  render: (args: ComponentProps<typeof TableCell>) => (
    <Table>
      <TableHeader>
        <tr>
          <th style={{ padding: 8 }}>Name</th>
        </tr>
      </TableHeader>
      <tbody>
        <TableRow>
          <TableCell {...args}>Disabled Cell</TableCell>
        </TableRow>
      </tbody>
    </Table>
  ),
};