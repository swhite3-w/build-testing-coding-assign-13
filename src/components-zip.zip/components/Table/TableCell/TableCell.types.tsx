import type React from "react";

export type TableCellProps = {
  children: React.ReactNode;
  disabled?: boolean;
  backgroundColor?: string;
};