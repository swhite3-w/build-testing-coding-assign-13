import type { Meta, StoryObj } from "@storybook/react-webpack5";
import { Table } from "../Table";
import { TableHeader } from "../TableHeader";
import { TableRow } from "./TableRow";
import type { ComponentProps } from "react";

const meta: Meta<typeof TableRow> = {
  title: "Components/TableRow",
  component: TableRow,
  argTypes: {
    backgroundColor: { control: "color" },
    disabled: { control: "boolean" },
  },
};

export default meta;
type Story = StoryObj<typeof TableRow>;

export const Default: Story = {
  args: {
    backgroundColor: "transparent",
    disabled: false,
  },
  render: (args: ComponentProps<typeof TableRow>) => (
    <Table>
      <TableHeader>
        <tr>
          <th style={{ textAlign: "left", padding: 8 }}>Name</th>
          <th style={{ textAlign: "left", padding: 8 }}>Value</th>
        </tr>
      </TableHeader>
      <tbody>
        <TableRow disabled={args.disabled} backgroundColor={args.backgroundColor}>
          <td style={{ padding: 8 }}>Row 1</td>
          <td style={{ padding: 8 }}>123</td>
        </TableRow>
      </tbody>
    </Table>
  ),
};

export const Disabled: Story = {
  args: {
    backgroundColor: "transparent",
    disabled: true,
  },
  render: (args: ComponentProps<typeof TableRow>) => (
    <Table>
      <TableHeader>
        <tr>
          <th style={{ textAlign: "left", padding: 8 }}>Name</th>
          <th style={{ textAlign: "left", padding: 8 }}>Value</th>
        </tr>
      </TableHeader>
      <tbody>
        <TableRow disabled={args.disabled} backgroundColor={args.backgroundColor}>
          <td style={{ padding: 8 }}>Row 1</td>
          <td style={{ padding: 8 }}>123</td>
        </TableRow>
      </tbody>
    </Table>
  ),
};